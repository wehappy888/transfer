package org.wayne.framework.starter.mq.service;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-11 11:33
 */
public interface MQMessageListener {

    void publish(String topic, Object message);

}
