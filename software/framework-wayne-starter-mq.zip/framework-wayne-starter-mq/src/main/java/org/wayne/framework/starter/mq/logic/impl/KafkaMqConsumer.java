package org.wayne.framework.starter.mq.logic.impl;

import com.google.protobuf.MessageOrBuilder;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.BatchAcknowledgingConsumerAwareMessageListener;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import org.wayne.framework.starter.mq.config.KafkaConfigProperties;
import org.wayne.framework.starter.mq.logic.IMQConsumer;
import org.wayne.framework.starter.mq.logic.LogicExecutionHandler;
import org.wayne.framework.starter.mq.utils.ByteUtils;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-29 10:55
 */
@Slf4j
@Component
public class KafkaMqConsumer<T> implements IMQConsumer<String> {

    private Map<String, T> messageBuilderMap = new HashMap<>();

    @Autowired
    private KafkaConfigProperties kafkaConfigProperties;

    private Map<String, LogicExecutionHandler> logicMap = new ConcurrentHashMap<>();

    public void setMessageBuilder(String topic, T messageBuilder) {
        this.messageBuilderMap.put(topic, messageBuilder);
    }

    public void setLogicExecutionHandler(String topic, LogicExecutionHandler logicExecutionHandler) {
        this.logicMap.put(topic, logicExecutionHandler);
    }

    @Override
    public void init(List<String> topics) {

        for (String topic : topics) {
            //1.定义consumer的参数
            Properties properties = new Properties();
            properties.put("bootstrap.servers", kafkaConfigProperties.getBootstrapServers());
            properties.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
            properties.put("value.deserializer", "org.wayne.framework.starter.mq.serializer.kafka.CustomKafkaDeserializer");
            properties.put("group.id", kafkaConfigProperties.getConsumer().getGroupId());

            //订阅主题
            KafkaConsumer<String, String> consumer = new KafkaConsumer<>(properties);
            consumer.subscribe(Collections.singletonList(topic));
            log.info("kafka主题：[{}] 消费者消息监听启动成功", topic);


            //2.创建默认的consumerFactory
            DefaultKafkaConsumerFactory consumerFactory = new DefaultKafkaConsumerFactory(properties);

            //3.定义消费者容器配置信息
            ContainerProperties containerProperties = new ContainerProperties(topic);
            containerProperties.setGroupId(kafkaConfigProperties.getConsumer().getGroupId());
            containerProperties.setMessageListener(new BatchAcknowledgingConsumerAwareMessageListener<String, String>() {

                @Override
                public void onMessage(List<ConsumerRecord<String, String>> data, Acknowledgment acknowledgment, Consumer<?, ?> consumer) {
                    log.info("kafka 主题:[{}],接收到新消息:[{}],线程：[{}]", topic, data, Thread.currentThread().getName());

                    for (ConsumerRecord<String, String> consumerRecord : data) {
                        try {
                            //此处只处理pb消息
                            if(messageBuilderMap.get(topic) instanceof MessageOrBuilder){
                                byte[] bytes = ByteUtils.hexStringToByteArray(consumerRecord.value());
                                logicMap.get(consumerRecord.topic()).execution(((MessageOrBuilder)messageBuilderMap.get(topic)).getDefaultInstanceForType().getParserForType().parseFrom(bytes));
                            }else{
                                //不是PB格式的消息统一按String类型处理
                                logicMap.get(consumerRecord.topic()).execution(new String(ByteUtils.hexStringToByteArray(consumerRecord.value())));
                            }
                            log.info("kafka 调用主题[{}]业务消费逻辑[{}]成功", topic, logicMap.get(consumerRecord.topic()).getClass().getName());
                        } catch (Exception e) {
                            //如果消息格式不是pb，提示用户，不做次消息业务逻辑处理，直接确认消息
                            String message = consumerRecord.value();
                            log.error("kafka消息：[{}] 不是pb格式，没有找到对应的消费者", message);
                            e.printStackTrace();
                        }
                    }
                }
            });

            //4.消费者并发消息监听器，执行doStart()方法
            ConcurrentMessageListenerContainer messageListenerContainer = new ConcurrentMessageListenerContainer(consumerFactory, containerProperties);
            messageListenerContainer.start();
        }
    }
}
