package org.wayne.framework.starter.mq.service;


import org.wayne.framework.starter.mq.logic.LogicExecutionHandler;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-28 11:43
 */
public abstract class MQMessageConsumerService<T> implements LogicExecutionHandler<T> {

    protected T messageBuilder;

    public MQMessageConsumerService(T messageBuilder) {
        this.messageBuilder = messageBuilder;
    }

    public T getMessageBuilder() {
        return messageBuilder;
    }

    public abstract void execution(T message);
}
