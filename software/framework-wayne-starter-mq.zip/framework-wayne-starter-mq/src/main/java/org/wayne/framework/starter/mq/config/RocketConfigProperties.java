package org.wayne.framework.starter.mq.config;

import lombok.Data;
import org.apache.rocketmq.spring.autoconfigure.RocketMQProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-16 10:52
 */
@Data
@Component
@ConfigurationProperties(prefix = "rocketmq", ignoreInvalidFields = true)
public class RocketConfigProperties {

    private String nameServer  = "localhost:9876";

    private RocketMQProperties.Producer producer = new RocketMQProperties.Producer();
}
