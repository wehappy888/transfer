package org.wayne.framework.starter.mq.handler;

import org.springframework.beans.factory.InitializingBean;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-11 15:05
 */
public abstract class AbstractMQMessageHandler implements MQMessageHandler, InitializingBean {

    @Override
    public String send(String topic, Object message) {
        return null;
    }

}
