package org.wayne.framework.starter.mq.config;

import com.google.protobuf.Message;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;
import org.wayne.framework.starter.mq.annotation.MQReceiveListener;
import org.wayne.framework.starter.mq.annotation.MQSendListener;
import org.wayne.framework.starter.mq.constant.MQTypes;
import org.wayne.framework.starter.mq.factory.MQSelectorFactory;
import org.wayne.framework.starter.mq.logic.LogicExecutionHandler;
import org.wayne.framework.starter.mq.logic.impl.KafkaMqConsumer;
import org.wayne.framework.starter.mq.logic.impl.RocketMqConsumer;
import org.wayne.framework.starter.mq.service.MQMessageConsumerService;
import org.wayne.framework.starter.mq.service.MQMessageService;
import org.wayne.framework.starter.mq.utils.ByteUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.*;
import java.util.*;

import static org.apache.commons.codec.Charsets.UTF_8;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-11 11:01
 */
@Component
@Slf4j
public class MQListenerParser implements ApplicationContextAware, InitializingBean {

    @Value("${mq.selector}")
    private String mqSelector;

    @Autowired
    private MQMessageService mqMessageService;

    @Autowired
    private RocketMqConsumer rocketMqConsumer;

    @Autowired
    private KafkaMqConsumer kafkaMqConsumer;

    private ApplicationContext applicationContext;


    @SneakyThrows
    @Override
    public void afterPropertiesSet() {
        Map<String, Object> listenerBeans = getListenerBeans(Controller.class, RestController.class, Service.class, Component.class);
        for (Object listener : listenerBeans.values()) {
            for (Method method : listener.getClass().getDeclaredMethods()) {
                if (!method.isAnnotationPresent(MQSendListener.class)) {
                    continue;
                }
                //获取到@HlhtListener注解的类方法，设置监听
                mqMessageService.setWorkListener((topic, message) -> {
                    try {
                        //如果新增消息中间件，这块需要动态添加
                        if (MQTypes.KAFKA.getType().equals(mqSelector)) {
                            method.invoke(listener, topic, message);
                        } else if (MQTypes.ROCKET_MQ.getType().equals(mqSelector)) {
                            if (message instanceof Message) {
                                // 消息内容为Messag类型时，发送RocketMq主题时做特殊处理，
                                // 将消息体先转换为字节数据，再将字节数组转换为十六进制的字符串
                                // 消费消息的时候，反向解即可
                                byte[] bytes = ((Message) message).toByteArray();
                                message = ByteUtils.byteArrayToHexString(bytes);
                            } else {
                                message = ((String) message).getBytes(UTF_8);
                            }
                            method.invoke(listener, topic, message);
                        } else {
                            method.invoke(listener, topic, message);
                        }
                    } catch (IllegalAccessException | InvocationTargetException e) {
                        e.printStackTrace();
                    }
                });
            }
        }

        //扫描 @MQReceiveListener 注解，获取主题后，创建该主题的消费者监听
        Map<String, Object> beansWithAnnotation = applicationContext.getBeansWithAnnotation(MQReceiveListener.class);
        List<String> topicList = new ArrayList<>();
        for (String key : beansWithAnnotation.keySet()) {
            Object object = beansWithAnnotation.get(key);
            Annotation[] annotations = object.getClass().getAnnotations();
            for (Annotation annotation : annotations) {
                if (annotation.annotationType().equals(MQReceiveListener.class)) {
                    InvocationHandler invocationHandler = Proxy.getInvocationHandler(annotation);
                    Map<String, String> map = (Map<String, String>) getFieldValue(invocationHandler, "memberValues");
                    Set<String> topics = map.keySet();
                    for (String topicKey : topics) {
                        String topic = map.get(topicKey);
                        topicList.add(topic);
                        //如果新增消息中间件，这块需要动态添加
                        if (MQTypes.KAFKA.getType().equals(mqSelector)){
                            kafkaMqConsumer.setLogicExecutionHandler(topic, (LogicExecutionHandler) object);
                            kafkaMqConsumer.setMessageBuilder(topic, ((MQMessageConsumerService) object).getMessageBuilder());
                        } else if (MQTypes.ROCKET_MQ.getType().equals(mqSelector)){
                            rocketMqConsumer.setLogicExecutionHandler(topic, (LogicExecutionHandler) object);
                            rocketMqConsumer.setMessageBuilder(topic, ((MQMessageConsumerService) object).getMessageBuilder());
                        }



                    }
                }
            }
        }
        //如果新增消息中间件，这块需要动态添加
        if (MQTypes.KAFKA.getType().equals(mqSelector)){
            kafkaMqConsumer.init(topicList);
        }else if (MQTypes.ROCKET_MQ.getType().equals(mqSelector)){
            rocketMqConsumer.init(topicList);
        }
    }

    public static <T> Object getFieldValue(T object, String property) {
        if (object != null && property != null) {
            Class<T> currClass = (Class<T>) object.getClass();

            try {
                Field field = currClass.getDeclaredField(property);
                field.setAccessible(true);
                return field.get(object);
            } catch (NoSuchFieldException e) {
                throw new IllegalArgumentException(currClass + " has no property: " + property);
            } catch (IllegalArgumentException e) {
                throw e;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    private Map<String, Object> getListenerBeans(Class<? extends Annotation>... annotationTypes) {
        Map<String, Object> listenerBeans = new LinkedHashMap<>();
        for (Class<? extends Annotation> annotationType : annotationTypes) {
            Map<String, Object> annotationBeansMap = applicationContext.getBeansWithAnnotation(annotationType);
            listenerBeans.putAll(annotationBeansMap);
        }
        return listenerBeans;
    }

    /**
     * 处理所有 消息中间件的请求，用户只关系怎么发送，这块只负责 发送到kafka或者rocketmq
     *
     * @param topic   消息主题
     * @param message 消息内容
     */
    @MQSendListener
    public void listen(String topic, Object message) {
        String sendStatus = MQSelectorFactory.getInvokeStrategy(mqSelector).send(topic, message);
        if ("success".equals(sendStatus)) {
            log.info("消息发送到主题成功");
        } else {
            log.error("消息发送到主题失败");
        }
    }
}
