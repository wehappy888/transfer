package org.wayne.framework.starter.mq.constant;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-11 15:12
 */
public enum MQTypes {

    KAFKA("kafka", "Apache Kafka消息中间件"),
    ROCKET_MQ("rocketMq", "Apache RocketMq消息中间件");
    private final String type;
    private final String name;

    MQTypes(String type, String name) {
        this.type = type;
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public String getName() {
        return name;
    }
}
