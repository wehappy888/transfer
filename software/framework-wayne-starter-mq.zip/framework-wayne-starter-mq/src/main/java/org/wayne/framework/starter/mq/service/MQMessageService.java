package org.wayne.framework.starter.mq.service;

import org.springframework.stereotype.Service;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-11 12:57
 */
@Service
public class MQMessageService {

    private MQMessageListener mqMessageListener;

    public void setWorkListener(MQMessageListener mqMessageListener) {
        this.mqMessageListener = mqMessageListener;
    }

    public void sendMessage(String topic, Object message) {
        mqMessageListener.publish(topic, message);
    }

}
