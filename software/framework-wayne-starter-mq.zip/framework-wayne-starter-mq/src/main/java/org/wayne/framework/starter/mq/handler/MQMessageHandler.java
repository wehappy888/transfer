package org.wayne.framework.starter.mq.handler;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-11 15:02
 */
public interface MQMessageHandler {

    String send(String topic, Object message);

}
