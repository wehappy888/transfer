package org.wayne.framework.starter.mq.serializer.kafka;

import com.google.protobuf.Message;
import org.apache.kafka.common.serialization.Serializer;

import java.util.Map;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-13 14:57
 */
public class ProtocolBuffersSerializer implements Serializer<Message> {

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {

    }

    @Override
    public byte[] serialize(String topic, Message data) {
        return data.toByteArray();
    }

    @Override
    public void close() {

    }

}
