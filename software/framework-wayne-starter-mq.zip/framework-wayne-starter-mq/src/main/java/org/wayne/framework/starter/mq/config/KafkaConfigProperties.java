package org.wayne.framework.starter.mq.config;

import lombok.Data;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-16 9:18
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "spring.kafka", ignoreInvalidFields = true)
public class KafkaConfigProperties {

    private List<String> bootstrapServers = new ArrayList(Collections.singletonList("localhost:9092"));

    private final KafkaProperties.Consumer consumer = new KafkaProperties.Consumer();

    private final KafkaProperties.Producer producer = new KafkaProperties.Producer();

}
