package org.wayne.framework.starter.mq.logic.impl;

import com.google.protobuf.MessageOrBuilder;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import org.apache.rocketmq.common.message.MessageExt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.wayne.framework.starter.mq.config.RocketConfigProperties;
import org.wayne.framework.starter.mq.logic.IMQConsumer;
import org.wayne.framework.starter.mq.logic.LogicExecutionHandler;
import org.wayne.framework.starter.mq.utils.ByteUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * rocketmq消息订阅统一订阅入口，并绑定对应的执行业务代码逻辑
 *
 * @author wangen
 * @version 1.0
 * @date 2021-09-28 14:11
 */
@Slf4j
@Component
public class RocketMqConsumer<T> implements IMQConsumer<String> {

    private Map<String, T> messageBuilderMap = new HashMap<>();

    @Autowired
    private RocketConfigProperties rocketConfigProperties;

    private Map<String, LogicExecutionHandler> logicMap = new ConcurrentHashMap<>();

    public void setMessageBuilder(String topic, T messageBuilder) {
        this.messageBuilderMap.put(topic, messageBuilder);
    }

    public void setLogicExecutionHandler(String topic, LogicExecutionHandler logicExecutionHandler) {
        this.logicMap.put(topic, logicExecutionHandler);
    }

    @SneakyThrows
    @Override
    public void init(List<String> topics) {
        for (String topic : topics) {
            //Instantiate with specified consumer group name.
            DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(rocketConfigProperties.getProducer().getGroup() + "_" + topic);

            //指定rocketmq地址
            consumer.setNamesrvAddr(rocketConfigProperties.getNameServer());

            // Subscribe one more  topics to consume. *表示订阅所有tags
            consumer.subscribe(topic, "*");

            // Register callback to execute on arrival of messages fetched from brokers.
            consumer.registerMessageListener(new MessageListenerConcurrently() {

                @Override
                public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> messageExts,
                                                                ConsumeConcurrentlyContext context) {
                    log.info("rocketMq 主题:[{}],接收到新消息:[{}],线程：[{}]", topic, messageExts, Thread.currentThread().getName());
                    for (MessageExt messageExt : messageExts) {
                        try {
                            //此处只处理pb消息
                            if(messageBuilderMap.get(topic) instanceof MessageOrBuilder){
                                byte[] bytes = ByteUtils.hexStringToByteArray(new String(messageExt.getBody()));
                                logicMap.get(context.getMessageQueue().getTopic()).execution(((MessageOrBuilder)messageBuilderMap.get(topic)).getDefaultInstanceForType().getParserForType().parseFrom(bytes));
                            }else{
                                //不是PB格式的消息统一按String类型处理
                                logicMap.get(context.getMessageQueue().getTopic()).execution(new String(ByteUtils.hexStringToByteArray(new String(messageExt.getBody()))));
                            }
                            log.info("rocketMq 调用主题[{}]业务消费逻辑[{}]成功",topic,logicMap.get(context.getMessageQueue().getTopic()).getClass().getName());
                        } catch (Exception e) {
                            //如果消息格式不是pb，提示用户，不做次消息业务逻辑处理，直接确认消息
                            String message = new String(messageExt.getBody());
                            log.error("rocketMq消息：[{}] 不是pb格式，没有找到对应的消费者", message);
                            e.printStackTrace();
                        }
                    }
                    return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
                }
            });
            //Launch the consumer instance.
            consumer.start();

            log.info("rocketMq主题：[{}] 消费者消息监听启动成功", topic);
        }
    }
}
