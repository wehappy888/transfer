package org.wayne.framework.starter.mq.serializer.kafka;

import org.apache.kafka.common.serialization.Deserializer;
import org.wayne.framework.starter.mq.utils.ByteUtils;

import java.util.Map;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-13 14:57
 */
public class ProtocolBuffersDeserializer implements Deserializer<String> {

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {

    }

    @Override
    public String deserialize(String topic, byte[] data) {
        return ByteUtils.byteArrayToHexString(data);
    }

    @Override
    public void close() {

    }
}
