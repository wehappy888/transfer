package org.wayne.framework.starter.mq.handler.impl;

import cn.hutool.core.util.ObjectUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.client.producer.TransactionMQProducer;
import org.apache.rocketmq.client.producer.selector.SelectMessageQueueByHash;
import org.apache.rocketmq.common.UtilAll;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.apache.rocketmq.spring.support.RocketMQMessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.wayne.framework.starter.mq.config.RocketConfigProperties;
import org.wayne.framework.starter.mq.constant.MQTypes;
import org.wayne.framework.starter.mq.factory.MQSelectorFactory;
import org.wayne.framework.starter.mq.handler.AbstractMQMessageHandler;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-11 15:09
 */
@Component
@Slf4j
public class MQMessageHandlerForRocketmq extends AbstractMQMessageHandler {

    @Value("${mq.selector}")
    private String mqSelector;

    @Autowired
    private RocketConfigProperties rocketConfigProperties;

    private RocketMQTemplate rocketMQTemplate;

    public RocketMQTemplate getRocketMQTemplate() {
        return rocketMQTemplate;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if (MQTypes.ROCKET_MQ.getType().equals(mqSelector)) {

            MQSelectorFactory.register(MQTypes.ROCKET_MQ.getType(), this);

            rocketMQTemplate = new RocketMQTemplate();
            rocketMQTemplate.setCharset("UTF-8");

            TransactionMQProducer producer = new TransactionMQProducer();
            producer.setNamesrvAddr(rocketConfigProperties.getNameServer());
            producer.setProducerGroup(rocketConfigProperties.getProducer().getGroup() + "-" + System.currentTimeMillis());
            producer.setInstanceName(String.valueOf(UtilAll.getPid()));
            rocketMQTemplate.setProducer(producer);

            rocketMQTemplate.setMessageQueueSelector(new SelectMessageQueueByHash());

            RocketMQMessageConverter rocketMQMessageConverter = new RocketMQMessageConverter();
            rocketMQTemplate.setMessageConverter(rocketMQMessageConverter.getMessageConverter());

            rocketMQTemplate.afterPropertiesSet();
        }

    }

    @Override
    public String send(String topic, Object message) {

        log.info("rocketmq router receive message, topic:[{}], message:[{}]", topic, message);

        if (ObjectUtil.isEmpty(message)) {
            return "消息内容为空";
        }
        rocketMQTemplate.getProducer().setProducerGroup(rocketConfigProperties.getProducer().getGroup() + topic);
        rocketMQTemplate.convertAndSend(topic, message);

        log.info("rocketmq router transfer message successful, topic:[{}], message:[{}]", topic, message);
        return "success";
    }

}
