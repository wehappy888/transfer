package org.wayne.framework.starter.mq.logic;

/**
 * 消费者业务代码统一执行入口
 *
 * @author wangen
 * @version 1.0
 * @date 2021-09-28 11:39
 */
public interface LogicExecutionHandler<T> {

    void execution(T message);

}
