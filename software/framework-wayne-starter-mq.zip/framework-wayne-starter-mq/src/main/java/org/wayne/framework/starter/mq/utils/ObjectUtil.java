package org.wayne.framework.starter.mq.utils;

import java.io.*;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-15 14:25
 */
public class ObjectUtil {

    public static <T> byte[] objToByte(T t) throws IOException {
        ByteArrayOutputStream bos = null;
        try {

            bos = new ByteArrayOutputStream();
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(bos);
            objectOutputStream.writeObject(t);
            objectOutputStream.flush();
            return bos.toByteArray();
        } catch (IOException e) {
            throw e ;
        } finally {
            if(bos != null) {
                bos.close();
            }
        }
    }

    public static <T extends Serializable> T byteToObj(byte[] bytes) throws IOException, ClassNotFoundException {
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
        ObjectInputStream objectInputStream = null ;
        try {
            objectInputStream = new ObjectInputStream(byteArrayInputStream);
            return (T) objectInputStream.readObject() ;
        } catch (IOException | ClassNotFoundException e) {
            throw e ;
        } finally {
            try {
                byteArrayInputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if(objectInputStream != null) {
                try {
                    objectInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
