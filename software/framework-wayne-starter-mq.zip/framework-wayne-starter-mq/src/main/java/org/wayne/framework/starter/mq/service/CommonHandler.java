package org.wayne.framework.starter.mq.service;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-13 17:44
 */
public interface CommonHandler {

    String onMessage();

}
