package org.wayne.framework.starter.mq.logic;

import java.util.List;

/**
 * 消费者订阅统一入口
 *
 * @author wangen
 * @version 1.0
 * @date 2021-09-28 15:56
 */
public interface IMQConsumer<T> {

    void init(List<T> topics);

}
