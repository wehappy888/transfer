package org.wayne.framework.starter.mq.factory;


import org.wayne.framework.starter.mq.handler.MQMessageHandler;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-11 15:00
 */
public class MQSelectorFactory {

    private static final Map<String, MQMessageHandler> strategyMap = new ConcurrentHashMap<>();

    public static void register(String name, MQMessageHandler handler) {
        strategyMap.put(name, handler);
    }

    public static MQMessageHandler getInvokeStrategy(String name) {
        return strategyMap.get(name);
    }

}
