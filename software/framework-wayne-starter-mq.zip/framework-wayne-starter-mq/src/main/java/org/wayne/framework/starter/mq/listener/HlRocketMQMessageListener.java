package org.wayne.framework.starter.mq.listener;

import com.google.protobuf.MessageOrBuilder;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.wayne.framework.starter.mq.utils.ByteUtils;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-15 16:26
 */
@Slf4j
public abstract class HlRocketMQMessageListener<T extends MessageOrBuilder> implements RocketMQListener<String> {

    protected T messageBuilder;

    public HlRocketMQMessageListener(T messageBuilder) {
        this.messageBuilder = messageBuilder;
    }

    @SneakyThrows
    public T getParseMessage(String message) {
        //这里解析消息时，需要和com.hlht.framework.starter.mq.config.MQListenerParser.afterPropertiesSet的方式匹配

        byte[] bytes;
        try {
            bytes = ByteUtils.hexStringToByteArray(message);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("消息：[{}] 不是PB消息，解析异常", message);
            return null;
        }
        return (T) messageBuilder.getDefaultInstanceForType().getParserForType().parseFrom(bytes);
    }

    @Override
    public void onMessage(String message) {
        T parseMessage = getParseMessage(message);
        if(parseMessage == null){
            return;
        }
        receive(parseMessage);
    }

    public abstract void receive(T parseMessage);
}
