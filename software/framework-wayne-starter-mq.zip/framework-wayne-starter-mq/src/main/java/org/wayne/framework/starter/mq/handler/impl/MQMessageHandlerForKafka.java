package org.wayne.framework.starter.mq.handler.impl;

import cn.hutool.core.util.ObjectUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.wayne.framework.starter.mq.config.KafkaConfigProperties;
import org.wayne.framework.starter.mq.constant.MQTypes;
import org.wayne.framework.starter.mq.factory.MQSelectorFactory;
import org.wayne.framework.starter.mq.handler.AbstractMQMessageHandler;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * @author wangen
 * @version 1.0
 * @date 2021-09-11 15:07
 */
@Component
@Slf4j
public class MQMessageHandlerForKafka extends AbstractMQMessageHandler {

    @Value("${mq.selector}")
    private String mqSelector;

    @Autowired
    private KafkaConfigProperties kafkaConfigProperties;

    private KafkaTemplate<String, Object> kafkaTemplate;

    @Autowired
    private ConcurrentKafkaListenerContainerFactory containerFactory;

    @Override
    public void afterPropertiesSet() {
        if (MQTypes.KAFKA.getType().equals(mqSelector)) {
            MQSelectorFactory.register(MQTypes.KAFKA.getType(), this);

            Map<String, Object> config = new HashMap();
            config.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, kafkaConfigProperties.getBootstrapServers());
            config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, kafkaConfigProperties.getProducer().getKeySerializer());
            config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, kafkaConfigProperties.getProducer().getValueSerializer());
            new DefaultKafkaProducerFactory(config);
            kafkaTemplate = new KafkaTemplate<>(() -> new KafkaProducer<>(config), true);
        } else{
            //当前启动的mq不是kakfa时，但是客户端有使用@KafkaListener 注解，设置自动启动监听，确保项目不会报错
            containerFactory.setAutoStartup(false);
        }
    }

    @Override
    public String send(String topic, Object message) {
        log.info("kafka router receive message, topic:[{}], message:[{}]", topic, message);

        if (ObjectUtil.isEmpty(message)) {
            return "消息内容为空";
        }

        kafkaTemplate.send(topic, message).addCallback(success -> {
            //消息发送主题
            String topicTarget = Objects.requireNonNull(success).getRecordMetadata().topic();
            //消息发送分区
            int partition = success.getRecordMetadata().partition();
            //消息offset
            long offset = success.getRecordMetadata().offset();
            log.info("发送消息成功：主题[{}]，分区[{}]，offset[{}]", topicTarget, partition, offset);
        }, failure -> log.error("发送消息失败：{}", failure.getMessage()));
        kafkaTemplate.flush();
        return "success";
    }

}
