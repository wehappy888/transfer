package org.wayne.framework.starter.mq.serializer.kafka;

import com.google.protobuf.Message;
import org.apache.kafka.common.serialization.Serializer;
import org.springframework.stereotype.Component;

import java.util.Map;

import static org.apache.commons.codec.Charsets.UTF_8;

/**
 * @author debug
 * @date 2020/6/22 18:42
 */
@Component
public class CustomKafkaSerializer implements Serializer<Object> {


    ProtocolBuffersSerializer protocolBuffersSerializer = new ProtocolBuffersSerializer();

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {

    }

    @Override
    public byte[] serialize(String topic, Object data) {
        if(data instanceof Message) {
            return protocolBuffersSerializer.serialize(topic,(Message) data) ;
        }else if(data instanceof String){
            return ((String)data).getBytes(UTF_8);
        }
        throw new RuntimeException("kafka反序列化只可以序列化");
    }

    @Override
    public void close() {

    }
}
